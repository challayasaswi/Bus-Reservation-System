package com.busreservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
